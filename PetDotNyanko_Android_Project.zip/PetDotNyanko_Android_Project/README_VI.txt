PET DOT! NYANKO - Android WebView project
=========================================

Đã trích xuất phần game TyranoScript từ file EXE và đặt vào:
app/src/main/assets/game/

Đây là PROJECT ANDROID để biên dịch, chưa phải file APK đã build.
Máy tạo hiện tại không có Android SDK/Gradle nên chưa thể xuất APK đã cài thử.

Cách build APK:
1. Cài Android Studio bản ổn định.
2. Mở thư mục PetDotNyanko_Android_Project.
3. Chờ Gradle Sync hoàn tất (cần Internet để tải Android Gradle Plugin).
4. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug thường nằm ở app/build/outputs/apk/debug/app-debug.apk.

Cấu hình:
- Landscape (ngang)
- WebView bật JavaScript, DOM Storage, local file access
- Giữ dữ liệu game trong assets
- minSdk 23, compileSdk 35

LƯU Ý:
- Đây là bản port thử nghiệm. Chưa xác nhận game chạy hoàn chỉnh trên Android.
- Cần kiểm thử âm thanh, lưu/tải game, thao tác chạm và các API/plugin đặc thù.
- Không có mã nguồn để bảo đảm mọi chức năng PC hoạt động y hệt.
