@echo off

if exist tmp.txt del tmp.txt
if exist list.txt del list.txt

cd /d %~dp0

dir *.jpg *.gif *.png /b /s > tmp.txt

setlocal enabledelayedexpansion

for /f "delims=" %%a in (tmp.txt) do (
  set line=%%a
  set line=!line:%~dp0="!
  set line=!line:\=/!
  set line=!line:.jpg=.jpg",!
  set line=!line:.gif=.gif",!
  set line=!line:.png=.png",!
  echo !line! >> list.txt
)

del tmp.txt
 
endlocal